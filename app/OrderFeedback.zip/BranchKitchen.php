<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BranchKitchen extends Model
{
    protected $fillable = [
        'kitachenTitle', 'branch_id'
    ];
}
